abstrack svenska
